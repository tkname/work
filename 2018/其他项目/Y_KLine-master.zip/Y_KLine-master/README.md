# Y_KLine(如果看着可以或者帮到了你，顺手给个赞呗~(*^__^*)~)

### 欢迎加群讨论更多：755873102
[![License MIT](https://img.shields.io/badge/license-MIT-green.svg?style=flat)]() &nbsp;
[![Support](https://img.shields.io/badge/support-iOS7.0+-blue.svg?style=flat)]() &nbsp;
[![Support](https://img.shields.io/badge/support-Autolayout-orange.svg?style=flatt)]() &nbsp;


## 普通K线

![普通K线](http://images2015.cnblogs.com/blog/784141/201605/784141-20160512232207577-321982028.png)
---
## 普通K线+MACD副图

![普通K线+MACD副图](http://images2015.cnblogs.com/blog/784141/201605/784141-20160512232150452-239970289.png)
---
## 普通K线+KDJ副图

![普通K线+KDJ副图](http://images2015.cnblogs.com/blog/784141/201605/784141-20160512232158515-2083550522.png)
---
## 分时图

![分时图](http://images2015.cnblogs.com/blog/784141/201605/784141-20160512232213202-486002469.png)
---
## 分时图+MACD副图

![分时图+MACD副图](http://images2015.cnblogs.com/blog/784141/201605/784141-20160512232142827-1554494273.png)
---
## 其他功能

![其他功能](http://images2015.cnblogs.com/blog/784141/201605/784141-20160512232934905-1866701052.png)
---
## 综合演示

![K线综合演示](http://images2015.cnblogs.com/blog/784141/201605/784141-20160512231537202-1121097756.gif)

咦,发现项目比较简单，不用复杂UI???

没事,清新简洁的第二版K线也已经就绪了♪(^∇^*) 
这边这边:https://github.com/yate1996/YYStock

### 欢迎加群讨论其它：755873102

#### 欢迎 [Fork](https://github.com/yate1996/Y_KLine/fork) & [Pull Request](https://github.com/yate1996/Y_KLine/pulls) & [提问](https://github.com/yate1996/Y_KLine/issues/new)，我会更有动力处理的的😄～


